# Local Math Library

## Overview

Local Math Library is a custom Python package that provides various mathematical operations and geometric calculations. It's designed to be a simple, easy-to-use library for basic and advanced mathematical computations.

## Features

The library includes the following modules:

1. Basic Math Operations
   - Addition
   - Subtraction
   - Multiplication
   - Division

2. Advanced Math Operations
   - Cube
   - Factorial
   - Square Root

3. Geometry
   - Circle area calculation
   - Square area calculation

4. Analytic Geometry
   - Distance between two points
   - Midpoint calculation

## Installation

To install the Local Math Library, run the following command:
